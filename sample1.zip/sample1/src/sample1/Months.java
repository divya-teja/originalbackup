package sample1;

public enum Months {
Jan,Feb,Mar,April,May,June,July,Aug,Sep,Oct,Nov,Dec;
}
