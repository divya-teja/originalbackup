package com.cg.leavemanagement.beans;

public class LeaveApplication {
	private int noOfDays,fromDate,toDate;
	private String leaveType;
	public LeaveApplication(int noOfDays, int fromDate, int toDate, String leaveType) {
		super();
		this.noOfDays = noOfDays;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.leaveType = leaveType;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public int getFromDate() {
		return fromDate;
	}
	public void setFromDate(int fromDate) {
		this.fromDate = fromDate;
	}
	public int getToDate() {
		return toDate;
	}
	public void setToDate(int toDate) {
		this.toDate = toDate;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fromDate;
		result = prime * result + ((leaveType == null) ? 0 : leaveType.hashCode());
		result = prime * result + noOfDays;
		result = prime * result + toDate;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeaveApplication other = (LeaveApplication) obj;
		if (fromDate != other.fromDate)
			return false;
		if (leaveType == null) {
			if (other.leaveType != null)
				return false;
		} else if (!leaveType.equals(other.leaveType))
			return false;
		if (noOfDays != other.noOfDays)
			return false;
		if (toDate != other.toDate)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "LeaveApplication [noOfDays=" + noOfDays + ", fromDate=" + fromDate + ", toDate=" + toDate
				+ ", leaveType=" + leaveType + "]";
	}
	
	

}
