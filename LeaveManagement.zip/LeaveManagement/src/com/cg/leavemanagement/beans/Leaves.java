package com.cg.leavemanagement.beans;

public class Leaves {
private int holdingLeaves,usedLeaves,totalLeaves;

public Leaves(int holdingLeaves, int usedLeaves, int totalLeaves) {
	super();
	this.holdingLeaves = holdingLeaves;
	this.usedLeaves = usedLeaves;
	this.totalLeaves = totalLeaves;
}

public int getHoldingLeaves() {
	return holdingLeaves;
}

public void setHoldingLeaves(int holdingLeaves) {
	this.holdingLeaves = holdingLeaves;
}

public int getUsedLeaves() {
	return usedLeaves;
}

public void setUsedLeaves(int usedLeaves) {
	this.usedLeaves = usedLeaves;
}

public int getTotalLeaves() {
	return totalLeaves;
}

public void setTotalLeaves(int totalLeaves) {
	this.totalLeaves = totalLeaves;
}

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + holdingLeaves;
	result = prime * result + totalLeaves;
	result = prime * result + usedLeaves;
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Leaves other = (Leaves) obj;
	if (holdingLeaves != other.holdingLeaves)
		return false;
	if (totalLeaves != other.totalLeaves)
		return false;
	if (usedLeaves != other.usedLeaves)
		return false;
	return true;
}

@Override
public String toString() {
	return "Leaves [holdingLeaves=" + holdingLeaves + ", usedLeaves=" + usedLeaves + ", totalLeaves=" + totalLeaves
			+ "]";
}


}
