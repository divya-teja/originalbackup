package com.cg.leavemanagement.services;

import com.cg.exceptionhandling.CustomerDetailsNotFoundException;
import com.cg.exceptionhandling.ServersDownException;

public interface LeaveManagementServices {
	int acceptcustomerDetails(String firstName,String lastName,String emailId,int mobileNo)throws ServersDownException;
	
	 int calcualteLeaves(int customerId)throws CustomerDetailsNotFoundException;
	

}
