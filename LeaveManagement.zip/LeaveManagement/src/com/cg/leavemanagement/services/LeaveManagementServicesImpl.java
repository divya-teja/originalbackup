package com.cg.leavemanagement.services;

import com.cg.exceptionhandling.CustomerDetailsNotFoundException;
import com.cg.exceptionhandling.ServersDownException;

public class LeaveManagementServicesImpl implements LeaveManagementServices  {

	@Override
	public int acceptcustomerDetails(String firstName, String lastName, String emailId, int mobileNo)
			throws ServersDownException {
		
		return 0;
	}

	@Override
	public int calcualteLeaves(int customerId) throws CustomerDetailsNotFoundException {

		return 0;
	}

}
