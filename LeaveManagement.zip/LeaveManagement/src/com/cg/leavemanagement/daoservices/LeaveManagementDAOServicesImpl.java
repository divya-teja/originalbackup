package com.cg.leavemanagement.daoservices;

public class LeaveManagementDAOServicesImpl {

}
