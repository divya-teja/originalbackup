package com.cg.leavemanagement.daoservices;

public interface LeaveManagementDAOServices {

}
