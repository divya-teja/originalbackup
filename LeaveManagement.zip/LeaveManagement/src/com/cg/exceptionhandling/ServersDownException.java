package com.cg.exceptionhandling;

@SuppressWarnings("serial")
public class ServersDownException extends Exception{

	public ServersDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServersDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ServersDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ServersDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
