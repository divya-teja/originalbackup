package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class MainClass {

	public static void main(String[] args) {
		
		try {
			PayrollServices payrollServices=new PayrollServicesImpl();
			PayrollDAOServices daoServices = new PayrollDAOServicesImpl();
			int associateID0=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID0);
			int associateID1=payrollServices.acceptAssociateDetails("a", "c", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID1);
			int associateID2=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID2);
			int associateID3=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID3);
			int associateID4=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID4);
			int associateID5=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID5);
			int associateID6=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID6);
			int associateID7=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID7);
			int associateID8=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID8);
			int associateID9=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID9);
			int associateID10=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID10);
			boolean a=daoServices.deleteAssociate(associateID8);
			//System.out.println(a);
			Associate associateList[]=daoServices.getAssociates();
			System.out.println(associateList.length);
			for(Associate associate:associateList)
				if(associate!=null)
					System.out.println(associate.getAssociateID());
			int associateID11=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID11);
			int associateID12=payrollServices.acceptAssociateDetails("satish", "mahajan", "satish@abcd.com", "Training", "Sr Con", "S1", 150000, 100000, 1000, 1000, 12345, "hdfc", "hdfc1");
			System.out.println(associateID12);
			payrollServices.getAssociateDetails(119);


			/*Associate a[] =payrollServices.getAllAssociatesDetails();
			for(int i=0;i<a.length;i++)
				System.out.println(" "+a[i]);*/
			//payrollServices.calculateNetSalary(associateID);
			//System.out.println("Montly Tax: "+payrollServices.getAssociateDetails(associateID).getSalary().getMonthlyTax());
			//System.out.println("NetSalary: "+payrollServices.getAssociateDetails(associateID).getSalary().getNetSalary());
			//int associateIdToBeSearched=111;
			//Associate associate=associateSearch(associateIdToBeSearched);
			/*Associate associate=associateSearch();
			if(associate!=null)
				System.out.println("Details Found");
			else
				System.out.println("Details Not found");*/

			/*for(int i=0;i<5;i++) {
				associateList[i]=new Associate[3];
				for(int j=0;j<3;j++) {
					associateList[i][j]=new Associate();
				}
			}

			Associate associate = new Associate(123, 25, "abi", "c", "hr", "chief", "a1", "abi@abcd.com");
			BankDetails bankdetails=new BankDetails(12345, "hdfc", "1234");
			Salary salary=new Salary(1000, 10, 11, 12, 13, 14, 15, 16, 17, 1014, 920);
			System.out.print(" AssociateID: "+associate.getAssociateID()
			+"\n YearlyInvestmentUnder80C: "+associate.getYearlyInvestmentUnder80C()
			+"\n FirstName: "+associate.getFirstName()
			+"\n LastName: "+associate.getLastName()
			+"\n Department: "+associate.getDepartment()
			+"\n Designation: "+associate.getDesignation()
			+"\n PanCard No: "+associate.getPancard()+"\n EmailId: "+associate.getEmailId());
	System.out.print("\n Bank Account No: "+bankdetails.getAccountNumber()
			+"\n BankName: "+bankdetails.getBankName()
			+"\n IFSC CODE: "+bankdetails.getIfscCode());
	System.out.print("\n Basic Salary: "+salary.getBasicSalary()
			+"\n hra:" +salary.getHra()
			+"\n ConveyenceAllowance: "+salary.getConveyenceAllowance()
			+"\n OtherAllowances: "+salary.getOtherAllowance()
			+"\n Personal Allowance: "+salary.getPersonalAllowance()
			+"\n Monthly Tax: " +salary.getMonthlyTax()
			+"\n EPF: "+salary.getEpf()
			+"\n CompanyPf: "+salary.getCompanyPf()
			+"\n Gratuity: "+salary.getGratuity()
			+"\n GrossSalary: "+salary.getGrossSalary()
			+"\n NetSalary: "+salary.getNetSalary());*/
			//associatedisplay();
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}

	}
	//public static Associate associateSearch(int associateID) {
	public static Associate associateSearch() {
		//public static void associatedisplay() {
		Associate associates[]=new Associate[4];
		/*associates[0]=new Associate(123, 60000, "Satish", "c", "hr", "chief", "a1", "abi@abcd.com");
	associates[1]=new Associate(124, 25, "abi", "c", "hr", "chief", "a1", "abi@abcd.com");
	associates[2]=new Associate(125, 25, "abi", "c", "hr", "chief", "a1", "abi@abcd.com");
	for(Associate associate:associates) {
		if( associate!=null && associate.getFirstName()=="Satish"&&associate.getYearlyInvestmentUnder80C()>50000) 
			return associate;

	}
	return null;*/
		associates[0]=new Associate(123, 100000, "Satish", "Mahajan", "Training", "Sr Con", "S1", "satish@abcd.com", new Salary(60000, 10, 25, 30, 25, 15, 89, 60, 10, 25, 30), new BankDetails(1234, "hdfc", "hdfc1"));
		associates[1]=new Associate(124, 30000, "abhi", "c", "tech", "dev", "a1","abhi@abcd.com",new Salary(50000, 10, 20, 30, 40, 50, 10, 10, 10, 60000, 70000), new BankDetails(1235, "sbi", "sbi1"));
		for(Associate associate:associates) {
			if( associate!=null && associate.getFirstName()=="Satish"&&associate.getYearlyInvestmentUnder80C()>50000&&associate.getSalary().getBasicSalary()==60000) 
				return associate;

		}
		//System.out.println(associates[0].getSalary().getBasicSalary();
		return null;

	}

}


